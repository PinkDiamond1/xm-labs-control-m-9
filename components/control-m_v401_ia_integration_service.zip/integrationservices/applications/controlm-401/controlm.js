importPackage(java.lang);
importPackage(java.util);
importPackage(java.io);
importPackage(java.net);
importPackage(java.sql);
importClass(Packages.com.alarmpoint.integrationagent.apxml.APXMLMessage);
importClass(Packages.com.alarmpoint.integrationagent.apxml.APXMLMessageImpl);
importClass(Packages.com.alarmpoint.integrationagent.apxml.APXMLToken);
importClass(Packages.com.thoughtworks.xstream.XStream);
importClass(Packages.com.thoughtworks.xstream.converters.reflection.PureJavaReflectionProvider);


var xStream = new XStream(new PureJavaReflectionProvider())
var INT_VERSION = "401";
var LOG_SOURCE = "controlm.js: ";
var BASE_PATH = "integrationservices/applications/controlm-";


// Core Javascript files provided by the IA
// Added to support REST API
load("lib/integrationservices/javascript/event.js");
load("integrationservices/lib/javascript/core/baseclass.js");
load("integrationservices/lib/javascript/core/logger.js");
load("integrationservices/lib/javascript/webservices/wsutil.js");
load("integrationservices/lib/javascript/webservices/soapfault.js");
load("integrationservices/lib/javascript/xmatters/xmattersws.js");


// Integration specific files
this.log = new Logger(this.LOG_SOURCE);
load(BASE_PATH + INT_VERSION + "/config.js");
load(BASE_PATH + INT_VERSION + "/util.js");
load(BASE_PATH + INT_VERSION + "/controlm-api.js");
load(BASE_PATH + INT_VERSION + "/apia-lifecycle.js");


var CONTROL_M_PASS = getPassword(CONTROLM_PASSWORD_FILE);


// Specifies that the xMatters priority is mapped to the property named "priority"
// Not used at this time.
function apia_remapped_data() {
  return {
    "priority" : "priority"
  };
}


// APClient.bin injection has been converted to a JavaScript object
// that can be serialized and sent to xMatters.
// This was done by virtue of the event.js include
function apia_event(form) {

    //split the parameters up and store them into the proper tokens to be sent to xMatters
    form.properties.controlm_server = (null === form.properties.controlm_server) ? "" : form.properties.controlm_server.trim();
    var tokens = form.properties.shout_msg.split(";");
    var order_id = tokens[0];
    form.properties["order_id"] = order_id;
    form.properties.recipients = tokens[1];
    form.properties["message"] = (tokens.length > 2) ? tokens[2] : "";
    form.properties["severity"] = (tokens.length > 3) ? tokens[3] : "";
    log.debug("form.properties: " + JSON.stringify(form.properties,null,4));
    
    if (form.properties.controlm_server.length === 0) {
        // Control-M will send requests with an empty value for controlm_server to signal the request for a delete action
        // So, just send up to xMatters to process
        return form;
    }

    log.info("Preparing for sending to xMatters.");

    // Sleep period between receiving a SHOUT Message and making the callback to the Control-M API for the job details
    try {
        Thread.sleep(SLEEP_PERIOD_BETWEEN_CALLBACK);
    } catch(ex) {
        Thread.currentThread().interrupt();
    }

    // Get the job details from the Control-M API
    log.debug("apia_event() - About to request job details from Control-M.");
    var processedResponse = controlmAPI.getJobDetailsForForm(order_id, form);
    log.debug("apia_event() - Queried API for job details and got : " + processedResponse);

    if (typeof processedResponse !== "undefined") {
        var wsutil = new WSUtil();
        unmarshalledResponse = wsutil.unmarshall(processedResponse, newGenericObject());
        for (var ur in unmarshalledResponse) {
            if (unmarshalledResponse.hasOwnProperty(ur)) {
                form.properties[ur] = unmarshalledResponse[ur];
            }
        }
    }

    // Return form to have it send to xmatters
    log.debug("apia_event() - About to return form: " + JSON.stringify(form,null,4));
    return form;

}


function apia_callback(msg) {
    var str = "Received message from xMatters:\n";
    str += JSON.stringify(msg,null,4);
    IALOG.info(str);
	try {

		switch (msg.xmatters_callback_type) {

			case "response":
				processResponse(msg);
			break;

			case "status":
			break;

			case "deliveryStatus":
				processDeliveryStatus(msg);
			break;
		}
	}
	catch (e) {
		IALOG.error("apia_callback(" + msg.eventidentifier + ", " + msg.xmatters_callback_type + "): caught Exception - name: [" + e.name + "], message [" + e.message + "]");
		if (e.message.indexOf('Invalid identifier') >= 0) {
			IALOG.info("apia_callback caught 'Invalid identifier' error");
		} else {
			throw e;
		}
	}	

}


/**
 * ---------------------------------------------------------------------------------------------------------------------
 * processResponse
 *
 * The main routine for handling user responses
 *
 * ---------------------------------------------------------------------------------------------------------------------
 */
function processResponse(callback_msg)
{
	IALOG.debug("Entering processResponse");
  
	var orderId = callback_msg.additionalTokens.order_id;
	var jobName = callback_msg.additionalTokens.job_name;
	var responseAction = callback_msg.response;
	var responder = callback_msg.recipient;
  
	// Create and execute Control-M command line based on response
	var cmdParams = new Array();
	var CTMPSM_COMMAND     = "ctmpsm";
	var CTMLOG_COMMAND     = "ctmlog";
	var CTMKILLJOB_COMMAND = "ctmkilljob";
	var ctmsecure = true;
  
	try {

		if (responseAction.equalsIgnoreCase("RERUN") || 
            responseAction.equalsIgnoreCase("FORCEOK") || 
            responseAction.equalsIgnoreCase("CONFIRM")) {
			cmdParams[0] = CTMPSM_COMMAND;
			cmdParams[1] = "-UPDATEAJF";
			cmdParams[2] = orderId;
			cmdParams[3] = responseAction;

		} else if (responseAction.equalsIgnoreCase("KILL") ) {
			cmdParams[0] = CTMKILLJOB_COMMAND;
			cmdParams[1] = "-ORDERID";
			cmdParams[2] = orderId;
			// e.g. cmdParams = "\"D:\\APPS\\Control-M Server\\ctm_server\\exe\\ctmkilljob.exe\"" + " -ORDERID " + orderId;

		} else if (responseAction.equalsIgnoreCase("LOGS")) {
			ctmsecure = false;
			cmdParams[0] = CTMLOG_COMMAND;
			cmdParams[1] = "LISTORD";
			cmdParams[2] = orderId;
			cmdParams[3] = "*";
			// e.g. cmdParams = "\"D:\\APPS\\Control-M Server\\ctm_server\\exe\\ctmlog.exe\"" + " LISTORD " + orderId + " *";

		} else if (responseAction.equalsIgnoreCase("OUTPUT")) {
			ctmsecure = false;
			cmdParams[0] = CTMPSM_COMMAND;
			cmdParams[1] = "-LISTSYSOUT";
			cmdParams[2] = orderId;
			// e.g. cmdParams = "\"D:\\APPS\\Control-M Server\\ctm_server\\exe\\ctmpsm.exe\"" + " -LISTSYSOUT " + orderId;

		} else if (responseAction.equalsIgnoreCase("STATISTICS")) {
			ctmsecure = false;
			cmdParams[0] = CTMPSM_COMMAND;
			cmdParams[1] = "-UPDATEAJF";
			cmdParams[2] = orderId;
			cmdParams[3] = "STATISTICS"; 
			// e.g. cmdParams = "\"D:\\APPS\\Control-M Server\\ctm_server\\exe\\ctmpsm.exe\"" + " -UPDATEAJF " + orderId + " STATISTICS";

		}

		var cmdResult = "";

		if( cmdParams.length > 0 ) {

			// Used for auditing purposes by all the commands, except logs.
			if( ctmsecure ) {
				cmdParams[ cmdParams.length ] = "-SECUSERAG";
				cmdParams[ cmdParams.length ] = responder;
			}

			IALOG.info("Executing command to Control-M : " + cmdParams);
			var cmdResultRaw = execute( cmdParams );
			var cmdResult = String(cmdResultRaw).valueOf();
			IALOG.debug("typeof cmdResultRaw: " + (typeof cmdResultRaw) + ", typeof cmdResult: " + (typeof cmdResult));
			IALOG.info("Result of command to Control-M: " + cmdResult);
			
			var ctlmCmdResult = {};
			ctlmCmdResult.recipients = [{"id": responder, "recipientType": "PERSON"}];
			ctlmCmdResult.properties = {};
			ctlmCmdResult.properties.job_name = jobName;
			ctlmCmdResult.properties.command_executed = responseAction;
			ctlmCmdResult.properties.order_id = orderId;
            ctlmCmdResult.properties.result = (cmdResult.length > XMATTERS_MAX_TEXT)?(cmdResult.substring(0,(XMATTERS_MAX_TEXT-3))+"..."):cmdResult;
            
			// Initialize the properties
			for (var p=0;p < MAX_RESULT_CHUNKS;p++) ctlmCmdResult.properties["message_"+p] = "";

			// Create chunked strings of less than max characters each for message
			var chunkedString = splitInChunks(cmdResult, XMATTERS_MAX_TEXT);
			
			// Put as much into the properties as possible
			for (var i=0;i < Math.min(chunkedString.length,MAX_RESULT_CHUNKS);i++) {
			  ctlmCmdResult.properties["message_"+i] = "" + chunkedString[i];
			}
			
			// If there were more chunks than could fit, add an elipsis at the end of the last chunk
			if (cmdResult.length > (MAX_RESULT_CHUNKS * XMATTERS_MAX_TEXT)) {
			  var pn = "message_"+(MAX_RESULT_CHUNKS-1);
			  ctlmCmdResult.properties[pn] = ctlmCmdResult.properties[pn].substring(0,(XMATTERS_MAX_TEXT-3)) + "...";
			}

			var cmdMsgJSON = JSON.stringify(ctlmCmdResult);
			
			IALOG.debug("Posting to xMatters IA: " + cmdMsgJSON);
			
			// Post command results back to xMatters
			XMIO.post(cmdMsgJSON, XMATTERS_CMDRESULT_FORM);
		}

	} catch (e) {
		IALOG.error("processResponse - Caught exception processing responseAction [" + responseAction + "] Exception: " + e);
	}

	IALOG.debug("processResponse - Finished call to management system for requestText: [" + responseAction);

	return;
}


/**
 * ---------------------------------------------------------------------------------------------------------------------
 * processDeliveryStatus
 *
 * The main routine for handling delivery status notations
 *
 * ---------------------------------------------------------------------------------------------------------------------
 */
function processDeliveryStatus(callback_msg) {
	var responder = callback_msg.recipient;
	var responseEvent = callback_msg.deliverystatus;
    
	// Create a comment for the successful or failed delivery of a notification
	var comment = NOTE_PREFIX + responseEvent + " to " + responder;
    IALOG.info("processDeliveryStatus - " + comment);
}


function execute( command ) {
    var result = "";
    var is = null;

    try {
        // Perform the command, then wait for it to finish.
        var p = Runtime.getRuntime().exec( command );
        is = p.getInputStream();
        result = parseStream(is);

    } catch(e) {
        if (e.javaException instanceof java.lang.IllegalThreadStateException) {
            // Sleep a little to save on CPU cycles
            Thread.currentThread().sleep(500);
        } else {
            log.error("Error occurred during Execute for cmd " + command);
            throw e;
        }

    } finally {
        try {
            if(is != null)
                is.close();
        } catch(ex){
          // Doesn't matter if we can't close the file.
        }
    }

    return result;
}


/*************************************************************************
 *
 * DESCRIPTION
 * This procedure will read the entire contents of the given input stream
 * and return it as a string.  While reading, it will parse any characters
 * that are XML-unfriendly and replace them with encoded alternatives.
 * Carriage returns and line feeds are NOT stripped from the stream, however
 * the 0x04 character (ASCII End Of Text marker) should be.  This is because
 * the Notification Server expects XML documents to be separated by that
 * character.
 *
 * INPUTS
 * InputStream is - The stream from which we want to read some data.
 *
 * OUTPUTS
 * The XML-friendly string representation of the data read from input.
 *
 * RETURNS
 * The empty string if nothing is read, otherwise all characters from the
 * input stream.
 *
 *************************************************************************/
function parseStream( is ) {
    var AMPERSAND = "&amp;";
    var QUOTE = "&quot;";
    var APOSTROPHE = "&apos;";
    var LESS_THAN = "&lt;";
    var GREATER_THAN = "&gt;";

    // Collect output from command as input to script
    //
    var inStream = new BufferedReader( new InputStreamReader( is ) );
    var result = new StringBuffer( 1024 );
    var escape = false;
    var input = 0;

    while( (input = inStream.read()) > -1 ) {
    // Strip out linefeeds and carriage returns in the data (unless escaped)
    // Also take care of any stray symbols that will cause XML problems.
 
        switch( String.fromCharCode(input) ) {
        // Removes the End Of Text marker that would cause the document to
        // be improperly parsed by the Notification Server if it was sent in
        // the middle of an XML document.
      
            case String.fromCharCode(0x04):
                break;

            case '&':
                result.append( AMPERSAND );
                break;
                
            case '<':
                result.append( LESS_THAN );
                break;
                
            case '>':
                result.append( GREATER_THAN );
                break;
                
            case '"':
                result.append( QUOTE );
                break;
                
            case '\'':
                result.append( APOSTROPHE );
                break;
                
            case '\\':
                if( escape )
                    result.append( "\\\\" );
                escape = !escape;
                break;
                
            case 'n':
            case 'r':
                if( escape ) {
                    result.append( '\\' );
                    escape = false;
                }

            default:
                if( (Integer.parseInt(input) > 27) || (input == 10) || (input == 13) )
                    result.append( String.fromCharCode(input) );
                break;
        }

        // If the last character was an escape character, simply append it.
        if( escape )
            result.append( '\\' );
    }

    return result.toString();
}


/**
 * Splits string <tt>s</tt> into chunks of size <tt>chunkSize</tt>
 *
 * @param s the string to split; must not be null
 * @param chunkSize number of chars in each chuck; must be greater than 0
 * @return The original string in chunks
 */
function splitInChunks(s, chunkSize) {
    var result = [];
    var sLen = s.length;
    for (var i = 0; i < sLen; i += chunkSize) {
        result.push(s.substring(i, Math.min(sLen, i + chunkSize)));
    }
    return result;
}


/**
 * Decrypts the password for the ServiceDeskUser used by the integration
 * @param passwordFile file/path of the file containing the encrypted password
 * @return decrypted password or an empty string if the password cannot be decrypted
 */
function getPassword(passwordFile) {
    try {
        var encryptionUtils = new EncryptionUtils();
        var file = new File(passwordFile);
        return encryptionUtils.decrypt(file);
    } catch (e) {
        return "";
    }
}

