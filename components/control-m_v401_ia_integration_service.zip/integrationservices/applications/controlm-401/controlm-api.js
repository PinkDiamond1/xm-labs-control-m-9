importPackage(java.lang);
importPackage(java.util);
importPackage(java.io);
importPackage(Packages.com.bmc.ctmem.emapi);


/*
Changes that were required to get this code working:
* changed the initalization of this.invoker: it is now explicitly an object of type com.bmc.ctmem.emapi.EMBasicXMLInvoker
* specify the server name while setting the properties for the invoker
* in the registerAPI function, changed the string.replace params to match the contents of EMAPI_register.xml (which is copied from emapi-<version>\examples\xml\EMAPI_register.xml)
* in registerAPI, rely on the CONTROL_M_PASS (which is decrypted from a file) to generate a passwordToken
* fixed the XML parsing logic that retrieves the userToken from the xmlResponse
*/


var ctmem = new Namespace(CONTROL_M_EMAPI_NAMESPACE);
var soap = new Namespace("http://schemas.xmlsoap.org/soap/envelope/");


var ControlMAPI = BaseClass.extend( {

    init : function () {
        // Control-M API variables
        this.registeredAPI = false;
        this.invoker;
        this.userToken = "";

        this.log = new Logger("ControlMAPI: ");
        this.initiateAPI();
        this.registerAPI();

        this.log.info("Control-M API initialization is complete.");
    },
  
    initiateAPI : function () {
        log.info("Entering initiateAPI. \n\n*** You can safely ignore the following 2 ERROR - properties will be loaded programatically. ***\n");
        var xmlResponse;
            
        try {
            var props = new Properties();
            props.setProperty("ServerURL", CONTROL_M_HOST_PROTOCOL + "://" + CONTROL_M_HOST_NAME + ":" + CONTROL_M_HOST_PORT);

            log.debug("About to invoke EMBasicXMLInvoker init using properties");
            EMBasicXMLInvoker.init(new Array(), props);

            log.debug("About to create EMBasicXMLInvoker instance");
            this.invoker = new EMBasicXMLInvoker();
        } catch(e) {
            // handle invoke failures
            log.error("ERROR in initiateAPI register : " + e.toString());
        }

        log.info("Exiting initiateAPI");
    },

    registerAPI : function () {
        log.info("Entering registerAPI");
        var xmlResponse;
        
        try {
            log.debug("*** BuildPasswordString attempting to get passwordToken with decrypted password... " + CONTROL_M_PASS );
            var passwordToken = this.invoker.BuildPasswordString(CONTROL_M_PASS);
            log.debug("*** BuildPasswordString retrieved passwordToken \n" + passwordToken);

            var xmlRequest = new Scanner( new File(CONTROL_M_REGISTER_XML) ).useDelimiter("\\A").next();

            // Note: the following parameters must match the ones in the local EMAPI_register file
            //  (copied from emapi-<version>/examples/xml/EMAPI_register.xml)
            xmlRequest = xmlRequest.replaceAll("emuser", CONTROL_M_USER);
            xmlRequest = xmlRequest.replaceAll("empass", passwordToken);
            xmlRequest = xmlRequest.replaceAll("EMAPI HOSTNAME", CONTROL_M_HOST_NAME);
      
            log.debug("Preparing to send the following xmlRequest to the ctrl-m v.9 api: \n" + xmlRequest );
            xmlResponse = this.invoker.invoke(xmlRequest);

        } catch(e) {
            // handle invoke failures
            log.error("ERROR in registerAPI register : " + e.toString());
            return;
        }
        // handle xml response
        log.debug("Received the following response from the ctrl-m v.9 api: \n" + xmlResponse );
    
        var wsutil = new WSUtil();
        var response = new XML(wsutil.formatStringForE4X(String(xmlResponse)));

        log.debug("Extracting the user_token from the xmlResponse..." );
        this.userToken = (response.*::Body.*::response_register.*::user_token).toString();
        
        log.info("\tReceived the following user_token: " + this.userToken);
        log.info("Exiting registerAPI");
    },

    /**
     * This function will retrieve the control-m job details from
     * the server for a particular job based on the job's orderId.
     * The jobs details will then be put into the form.
     * @param orderId, this is the orderId of the job to retrieve
     * @param form
     */
    getJobDetailsForForm : function (orderId, form) {
        var xmlResponse;    
        log.info("getJobDetailsForForm entering - for orderId = " + orderId);
        
        // now try to get the job details
        try {
            var wsutil = new WSUtil();
            var retryAPI = true;
            var retries = 0;

            while((retries < API_NUMBER_OF_RETRIES) && retryAPI) {
        
                var xmlRequest = new Scanner( new File(CONTROL_M_RETRIEVE_JOBS_XML) ).useDelimiter("\\A").next();
                xmlRequest = xmlRequest.replaceAll("\\$USER_TOKEN\\$", this.userToken)
                xmlRequest = xmlRequest.replaceAll("\\$ORDER_ID\\$", orderId)

                log.debug("Calling EMXMLInvoker.invoke(xmlRequest) for xmlRequest " + xmlRequest);
                responseStr = this.invoker.invoke(xmlRequest);

                // get the response
                xmlResponse = new XML(wsutil.formatStringForE4X(String(responseStr))).soap::Body;

                // check for errors
                if ((xmlResponse.soap::Fault).length() > 0) {
                    log.error("The following SOAP Fault has occurred " + xmlResponse.soap::Fault);

                    xmlResponse = xmlResponse.soap::Fault;
                    //determine if it is a Invalid User Token and we need to re-register for a new one
                    var faultError = xmlResponse.detail.ctmem::fault_act_retrieve_jobs.ctmem::error_list.ctmem::error;
                    var faultMajorCode = faultError.@ctmem::major;
                    var faultMinorCode = faultError.@ctmem::minor;
                    var faultErrorMessage = faultError.ctmem::error_message;
          
                    // check to see if the user token has expired
                    if (faultMajorCode == AUTHORIZATION_REQUEST_MAJOR_CODE && faultMinorCode == AUTHORIZATION_REQUEST_MINOR_CODE) {
                        // try to register and rerun the request
                        log.debug("SOAP Error for faultMajorCode " + faultMajorCode + " and faultMinorCode " + faultMinorCode + " with faultErrorMessage " + faultErrorMessage + " we will try to do a API re-register to get the User Token");
                        this.registerAPI();
                    } else {
                        form.properties.message = "The following SOAP Error occurred for the API request to request_act_retrieve_jobs: " + xmlResponse;
                        retryAPI = false;
                    }
                } else {
                    xmlResponse = xmlResponse.ctmem::response_act_retrieve_jobs.ctmem::jobs.ctmem::job.ctmem::job_data;
                    // exit the retry API loop as we have the response
                    retryAPI = false;
                }
                
                retries++;
            }
        } catch(e) {
            // handle invoke failures
            log.error("ERROR in getJobDetailsForForm: " + e.toString());
        }
    
        log.debug("getJobDetailsForForm exiting with xmlResponse " + xmlResponse);
        return xmlResponse;
    },
  
    done : function () {
        log.debug("Calling EMBasicXMLInvoker.done()");
        EMBasicXMLInvoker.done();
    },

});
