/**
 * xMatters Control-M IA Integration Service Configuration
 */

// ----------------------------------------------------------------------------------------------------
// Name of filter to apply for local deduplication
// ----------------------------------------------------------------------------------------------------
var DEDUPLICATOR_FILTER = "controlm-401";

// ----------------------------------------------------------------------------------------------------
// Identifies Control-M Enterprise Manager Server
// ----------------------------------------------------------------------------------------------------
var CONTROL_M_USER = "<PUT YOUR ENTERPRISE MANAGER USER ID HERE>"; // Your Enterprise Manager User
var CONTROLM_PASSWORD_FILE = "conf/bmccontrolm.pwd"; // iapassword encrypted password for CONTROL_M_USER
var CONTROL_M_HOST_PROTOCOL = "http"; // Your configured host protocol (http, or https)
var CONTROL_M_HOST_NAME = "advisors-bmc-control-m-9-0-18-and-above";  
//                        Must match the "Control-M Server Name" reported in Start Menu / Control-M Configuration Manager - case-sensitive
var CONTROL_M_HOST_PORT = "18080"; // Port to reach Control-M EM Web Service

// ----------------------------------------------------------------------------------------------------
// Specifies how many retries to preform if a error in the API occurs
// This is also used for API timeouts to perform a re-connect for the API
// ----------------------------------------------------------------------------------------------------
var API_NUMBER_OF_RETRIES = 3;

// ----------------------------------------------------------------------------------------------------
// Control-M API properties (Change this based on your Control-M Version)
// ----------------------------------------------------------------------------------------------------
var CONTROL_M_EMAPI_NAMESPACE = "http://www.bmc.com/ctmem/schema918"; 
var CONTROL_M_REGISTER_XML = BASE_PATH + INT_VERSION + "/xmldata/EMAPI_register.xml";
var CONTROL_M_RETRIEVE_JOBS_XML = BASE_PATH + INT_VERSION + "/xmldata/EMAPI_act_retrieve_jobs.xml";
var AUTHORIZATION_REQUEST_MAJOR_CODE = "407";
var AUTHORIZATION_REQUEST_MINOR_CODE = "1";

// ----------------------------------------------------------------------------------------------------
// Configuration for the amount of time to sleep between receiving a SHOUT Message and making the callback to the Control-M API for the job details
// ----------------------------------------------------------------------------------------------------
var SLEEP_PERIOD_BETWEEN_CALLBACK = 3000; // 3 seconds in milliseconds

// ----------------------------------------------------------------------------------------------------
// Text to put infront of any messages sent back to Control-M by xMatters
// ----------------------------------------------------------------------------------------------------
var NOTE_PREFIX = "[xMatters] ";  // The Prefix which is added to the note comments for AlarmPoint

// ----------------------------------------------------------------------------------------------------
// Identifies the User ID and location of encrypted password for xMatters REST User that will be
// sending requests via WEB_SERVICE_URL and XMATTERS_CMDRESULT_FORM
// ----------------------------------------------------------------------------------------------------
var INITIATOR = 'rest-gcp-ctrl-m';
var PASSWORD = 'conf/.restuser.pwd';

// ----------------------------------------------------------------------------------------------------
// This value specifies the Integration Builder Entry Point used to inject events into xMatters.
// The actual variable is defined previously, we are just setting the value here.
// E.g. https://<yourco>.xmatters.com/api/integration/1/functions/4dc45f97-5dd1-4398-b4ce-ec96bf0356ef/triggers
// ----------------------------------------------------------------------------------------------------
WEB_SERVICE_URL = "<'Inbound Request from IA' INBOUND INTEGRATION ENDPOINT URL FROM YOUR XMATTERS INSTANCE>";

// ----------------------------------------------------------------------------------------------------
// This value specifies the Integration Builder Entry Point used to send Command Results back to xMatters.
// E.G. https://advisors.na5.xmatters.com/api/integration/1/functions/d6d4800f-7f49-4784-bbc2-e6f4091e89e1/triggers
// ----------------------------------------------------------------------------------------------------
var XMATTERS_CMDRESULT_FORM = "<'Trigger Command Result Form' INBOUND INTEGRATION ENDPOINT URL FROM YOUR XMATTERS INSTANCE>";

// ----------------------------------------------------------------------------------------------------
// The maximum size of a text property in xMatters
// ----------------------------------------------------------------------------------------------------
var XMATTERS_MAX_TEXT = 20000;
var MAX_RESULT_CHUNKS = 3;

// ----------------------------------------------------------------------------------------------------
// Callbacks requested for this integration service.
// Options may be one or more of: "status", "deliveryStatus", "response", "annotation";
// e.g. CALLBACKS = ["status", "deliveryStatus", "response", "annotation"];
// ----------------------------------------------------------------------------------------------------
CALLBACKS = ["response"];

